    $(document).ready(function() {
        $('#summernote>p>textarea').summernote();
    });
    // Добавление Placeholder
    $('#summernote>p>input').attr("placeholder", "Введите название статьи");
    
    //функция для отображения загружаемого изображения
    function showFile(e) {
        var files = e.target.files;
        for (var i = 0, f; f = files[i]; i++) {
          if (!f.type.match('image.*')) continue;
          var fr = new FileReader();
          fr.onload = (function(theFile) {
            return function(e) {
              var li = document.createElement('li');
              li.innerHTML = "<img src='" + e.target.result + "' />";
              document.getElementById('list').insertBefore(li, null);
            };
          })(f);
     
          fr.readAsDataURL(f);
        }
      }
     
      document.getElementById('id_article_images').addEventListener('change', showFile, false);