from django.shortcuts import render
from .models import Article
from .forms import ArticleForm
from django.core.paginator import Paginator
from django.views.generic.edit import CreateView
from django.urls import reverse_lazy
from django.views.generic import DetailView

def ArticleList(request):
    """
    Функция для вывода списка статей(Последних 10)
    """
    article_post = Article.objects.all()[:9]
    last_article = Article.objects.all()[:1]
    context = {
        'article_post': article_post,
        'last_article': last_article
    }
    return render(request,'article/index.html',context)

class ArticleFull(DetailView):
    """
    Класс-функция для чтения статьи
    """
    model = Article
    template_name = 'article/Article.html'

class ArticleAdd(CreateView):
    """
    Класс-Функция для добавления статьи
    """
    model = Article
    fields = ('article_title','article_text','article_images',)
    template_name = 'article/AddArticle.html' 
    articleForm = ArticleForm
    success_url = reverse_lazy('succeful')

    def get_context_data(self,**kwargs):
        context = super().get_context_data(**kwargs)
        return context

def succeful(request):
    """
    Перенаправление после успешной отправки статьи
    """
    return render(request,"article/index.html",{})

