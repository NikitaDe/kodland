from django.urls import path
from .views import ArticleAdd,ArticleList,ArticleFull

urlpatterns = [
    path('articleList/',ArticleList,name="ArticleList"),
    path('addArticle/',ArticleAdd.as_view(),name="AddArticle"),
    path('article/<int:pk>/', ArticleFull.as_view(), name='Article_Full'),
]