from django.db import models

class Article(models.Model):
    """
        Модель статьи
    """
    article_title = models.CharField(max_length = 200, verbose_name='Заголовок')
    article_text = models.TextField(verbose_name='Текст статьи')
    article_images = models.ImageField(null=True, upload_to='article_images',verbose_name='Илюстрация')
    article_published = models.DateTimeField(auto_now_add=True, db_index=True)
    class Meta:
        verbose_name_plural = 'Статьи'
        verbose_name = 'Статья'
        ordering = ['-article_published']
     