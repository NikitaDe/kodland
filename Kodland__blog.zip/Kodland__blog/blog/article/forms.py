from django.forms import ModelForm
from .models import Article
from django import forms

class ArticleForm(ModelForm):
    class Meta:
        model = Article
        fields = ('article_title','article_text','article_images',)
