from django.contrib import admin
from .models import Article

class ArticleAdm(admin.ModelAdmin):
    list_display = ('article_title','article_text','article_images',)
    
admin.site.register(Article)    
